
import numpy as np

class MyNeuralNetwork:
    def __init__(self, layer_sizes, activation='relu', learning_rate=0.01, epochs=100):
        self.layer_sizes = layer_sizes
        self.activation = activation
        self.learning_rate = learning_rate
        self.epochs = epochs
        self.weights = []
        self.biases = []
        self._initialize_weights()

    def _initialize_weights(self):
        for i in range(1, len(self.layer_sizes)):
            weight = np.random.randn(self.layer_sizes[i-1], self.layer_sizes[i]) * 0.1
            bias = np.zeros((1, self.layer_sizes[i]))
            self.weights.append(weight)
            self.biases.append(bias)

    def _activate(self, x):
        if self.activation == 'relu':
            return np.maximum(0, x)
        elif self.activation == 'sigmoid':
            return 1 / (1 + np.exp(-x))
        elif self.activation == 'linear':
            return x
        elif self.activation == 'tanh':
            return np.tanh(x)
        else:
            raise ValueError(f"Unknown activation function {self.activation}")

    def _activate_derivative(self, x):
        if self.activation == 'relu':
            return np.where(x > 0, 1, 0)
        elif self.activation == 'sigmoid':
            return x * (1 - x)
        elif self.activation == 'linear':
            return np.ones_like(x)
        elif self.activation == 'tanh':
            return 1.0 - np.tanh(x)**2
        else:
            raise ValueError(f"Unknown activation function {self.activation}")

    def forward_propagation(self, X):
        activations = [X]
        for i in range(len(self.weights)):
            z = np.dot(activations[-1], self.weights[i]) + self.biases[i]
            a = self._activate(z)
            activations.append(a)
        return activations

    def backward_propagation(self, activations, y):
        deltas = [activations[-1] - y]
        for i in reversed(range(len(deltas), len(self.weights))):
            delta = np.dot(deltas[-1], self.weights[i].T) * self._activate_derivative(activations[i])
            deltas.append(delta)
        deltas.reverse()
        return deltas

    def update_weights(self, activations, deltas):
        for i in range(len(self.weights)):
            self.weights[i] -= self.learning_rate * np.dot(activations[i].T, deltas[i])
            self.biases[i] -= self.learning_rate * np.sum(deltas[i], axis=0, keepdims=True)

    def train(self, X, y):
        for epoch in range(self.epochs):
            activations = self.forward_propagation(X)
            deltas = self.backward_propagation(activations, y)
            self.update_weights(activations, deltas)

    def predict(self, X):
        activations = self.forward_propagation(X)
        return activations[-1]

