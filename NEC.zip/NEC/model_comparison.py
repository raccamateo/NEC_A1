# Import Libraries
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.neural_network import MLPRegressor
from sklearn.metrics import mean_absolute_percentage_error

# Data Preparation Function
def load_and_split_data(url, test_size):
    df = pd.read_csv(url)
    X = df.iloc[:, :-1].values
    y = df.iloc[:, -1].values
    return train_test_split(X, y, test_size=test_size, random_state=42)


# URLs and the corresponding split ratios
dataset_urls = [
    "https://raw.githubusercontent.com/raccamateo/NEC_A1/main/standardized_turbine_data.csv",
    "https://raw.githubusercontent.com/raccamateo/NEC_A1/main/standardized_synthetic_data.csv",
    "https://raw.githubusercontent.com/raccamateo/NEC_A1/main/standardized_boston_housing_data.csv"
]
test_split_ratios = [0.15, 0.20, 0.20]  # Test split ratios for each dataset

datasets = [load_and_split_data(url, test_size) for url, test_size in zip(dataset_urls, test_split_ratios)]



# 3. Model Implementations
# Custom Neural Network Class (NN)
class NeuralNetwork:
    def __init__(self, layers, activation='relu', learning_rate=0.001):
        self.layers = layers
        self.activation = activation
        self.learning_rate = learning_rate
        self.weights = self._initialize_weights()

    def _initialize_weights(self):
        weights = {}
        for i in range(1, len(self.layers)):
            if self.activation == 'relu':
                weights[f'W{i}'] = np.random.randn(self.layers[i - 1], self.layers[i]) * np.sqrt(
                    2. / self.layers[i - 1])
            else:
                weights[f'W{i}'] = np.random.randn(self.layers[i - 1], self.layers[i]) * 0.1
            weights[f'b{i}'] = np.zeros((1, self.layers[i]))
        return weights

    def _activate(self, Z, activation_type):
        if activation_type == 'relu':
            return np.maximum(0, Z)
        elif activation_type == 'sigmoid':
            return 1 / (1 + np.exp(-Z))
        elif activation_type == 'linear':
            return Z
        elif activation_type == 'tanh':
            return np.tanh(Z)

    def _activate_derivative(self, Z, activation_type):
        if activation_type == 'relu':
            return np.where(Z > 0, 1, 0)
        elif activation_type == 'sigmoid':
            s = 1 / (1 + np.exp(-Z))
            return s * (1 - s)
        elif activation_type == 'linear':
            return np.ones_like(Z)
        elif activation_type == 'tanh':
            return 1 - np.tanh(Z) ** 2

    def _forward_propagation(self, X):
        cache = {'A0': X}
        for i in range(1, len(self.layers)):
            cache[f'Z{i}'] = np.dot(cache[f'A{i - 1}'], self.weights[f'W{i}']) + self.weights[f'b{i}']
            activation_func = self.activation if i < len(self.layers) - 1 else 'linear'
            cache[f'A{i}'] = self._activate(cache[f'Z{i}'], activation_func)
        return cache

    def _compute_loss(self, Y_hat, Y):
        return np.mean((Y_hat - Y) ** 2)

    def _backpropagation(self, cache, X, Y):
        gradients = {}
        Y = Y.reshape(-1, 1)  # Ensure Y is the correct shape
        dA = cache[f'A{len(self.layers) - 1}'] - Y
        for layer in reversed(range(1, len(self.layers))):
            activation_func = self.activation if layer < len(self.layers) - 1 else 'linear'
            dZ = dA * self._activate_derivative(cache[f'Z{layer}'], activation_func)
            dW = np.dot(cache[f'A{layer - 1}'].T, dZ) / X.shape[0]
            db = np.sum(dZ, axis=0, keepdims=True) / X.shape[0]
            if layer > 1:
                dA = np.dot(dZ, self.weights[f'W{layer}'].T)
            gradients[f'dW{layer}'] = dW
            gradients[f'db{layer}'] = db
        return gradients

    def _update_weights(self, gradients, clip_value=1.0):
        for i in range(1, len(self.layers)):
            dW = np.clip(gradients[f'dW{i}'], -clip_value, clip_value)
            db = np.clip(gradients[f'db{i}'], -clip_value, clip_value)
            self.weights[f'W{i}'] -= self.learning_rate * dW
            self.weights[f'b{i}'] -= self.learning_rate * db

    def fit(self, X, Y, epochs):
        for epoch in range(epochs):
            cache = self._forward_propagation(X)
            gradients = self._backpropagation(cache, X, Y)
            self._update_weights(gradients)
            if epoch % 100 == 0:
                loss = self._compute_loss(cache[f'A{len(self.layers) - 1}'], Y)
                print(f"Epoch {epoch}, Loss: {loss}")

    def predict(self, X):
        cache = self._forward_propagation(X)
        return cache[f'A{len(self.layers) - 1}']


# URLs and test sizes for datasets
dataset_urls = [
    "https://raw.githubusercontent.com/raccamateo/NEC_A1/main/standardized_turbine_data.csv",
    "https://raw.githubusercontent.com/raccamateo/NEC_A1/main/standardized_synthetic_data.csv",
    "https://raw.githubusercontent.com/raccamateo/NEC_A1/main/standardized_boston_housing_data.csv"
]
test_sizes = [0.15, 0.20, 0.20]

# Load and split the datasets
datasets = [load_and_split_data(url, test_size) for url, test_size in zip(dataset_urls, test_sizes)]

# Define parameters for the neural network for each dataset
nn_parameters = {
    # Example parameters; adjust as necessary
    'turbine': {'layers': [13, 10, 5, 1], 'activation': 'relu', 'learning_rate': 0.001, 'epochs': 1000},
    'synthetic': {'layers': [10, 8, 4, 1], 'activation': 'sigmoid', 'learning_rate': 0.001, 'epochs': 800},
    'boston': {'layers': [13, 5, 2, 1], 'activation': 'tanh', 'learning_rate': 0.005, 'epochs': 500}
}

# Training, Evaluating, and Plotting for Each Dataset
for i, ((X_train, X_test, y_train, y_test), params) in enumerate(zip(datasets, nn_parameters.values()), 1):
    # Correctly set the input size for the neural network
    input_size = X_train.shape[1]  # Number of features in the training data
    layers = [input_size] + params['layers'][1:]  # Adjust the first layer to match the input size

    # Initialize the neural network with the correct number of input neurons
    nn = NeuralNetwork(layers, activation=params['activation'], learning_rate=params['learning_rate'])
    nn.fit(X_train, y_train, epochs=params['epochs'])

    # Predict and evaluate
    nn_predictions = nn.predict(X_test)
    nn_mape = mean_absolute_percentage_error(y_test, nn_predictions)

    # Multiple Linear Regression
    mlr = LinearRegression()
    mlr.fit(X_train, y_train)
    mlr_predictions = mlr.predict(X_test)
    mlr_mape = mean_absolute_percentage_error(y_test, mlr_predictions)

    # MLP Regressor
    mlp = MLPRegressor(hidden_layer_sizes=(100,), activation='relu', random_state=42)
    mlp.fit(X_train, y_train)
    mlp_predictions = mlp.predict(X_test)
    mlp_mape = mean_absolute_percentage_error(y_test, mlp_predictions)

    # Plot results
    plt.figure(figsize=(12, 4))
    plt.subplot(1, 2, 1)
    plt.scatter(y_test, nn_predictions, alpha=0.7, color='blue', label='NN')
    plt.scatter(y_test, mlr_predictions, alpha=0.7, color='red', label='MLR')
    plt.scatter(y_test, mlp_predictions, alpha=0.7, color='green', label='MLP')
    plt.legend()
    plt.xlabel('Actual')
    plt.ylabel('Predicted')
    plt.title(f'Dataset {i} Predictions')

    plt.subplot(1, 2, 2)
    plt.bar(['NN', 'MLR', 'MLP'], [nn_mape, mlr_mape, mlp_mape], color=['blue', 'red', 'green'])
    plt.ylabel('MAPE')
    plt.title(f'Dataset {i} MAPE Comparison')
    plt.show()