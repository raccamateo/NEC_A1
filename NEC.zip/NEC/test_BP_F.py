import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from my_neural_network import MyNeuralNetwork
import matplotlib.pyplot as plt

# Function to calculate Mean Absolute Percentage Error (MAPE)
def mean_absolute_percentage_error(y_true, y_pred):
    y_true, y_pred = np.array(y_true), np.array(y_pred)
    return np.mean(np.abs((y_true - y_pred) / y_true)) * 100

# Load the dataset
url = "https://raw.githubusercontent.com/raccamateo/NEC_A1/main/standardized_boston_housing_data.csv"
wine_data = pd.read_csv(url)

# Separate features (X) and target variable (y)
X = wine_data.drop('MEDV', axis=1)
y = wine_data['MEDV']

# Split the dataset into training and validation sets
X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

# Initialize and train the custom neural network
num_features = X_train.shape[1]  # Number of features in the dataset
my_nn = MyNeuralNetwork(
    num_layers=6,  # Total number of layers (input, hidden, output)
    units_per_layer=[num_features, 9, 6, 9, 3, 1],  # Units in each layer
    num_epochs=5000,  # Number of epochs for training
    learning_rate=0.5,  # Learning rate for weight updates
    momentum=0.8,  # Momentum for gradient descent optimization
    validation_split=0.2  # Fraction of data to be used for validation
)
my_nn.fit(X_train.values, y_train.values)  # Fitting the model

# Predict with the trained model
my_nn_predictions = my_nn.predict(X_val.values)

# Calculate Mean Squared Error and MAPE for the model
my_nn_mse = mean_squared_error(y_val, my_nn_predictions)
my_nn_mape = mean_absolute_percentage_error(y_val, my_nn_predictions)

# Print the Mean Squared Error and MAPE
print(f"Mean Squared Error (MyNeuralNetwork): {my_nn_mse}")
print(f"Mean Absolute Percentage Error (MyNeuralNetwork): {my_nn_mape}")

# Scatter plot to visualize the predictions
plt.figure(figsize=(8, 6))
plt.scatter(y_val, my_nn_predictions, alpha=0.5)
plt.plot([y_val.min(), y_val.max()], [y_val.min(), y_val.max()], 'k--', lw=2)
plt.title('MyNeuralNetwork Predictions')
plt.xlabel('True Values')
plt.ylabel('Predictions')
plt.show()
